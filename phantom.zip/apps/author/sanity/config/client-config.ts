// apps/author/sanity/config/client-config.ts

const config = {
  projectId: "rkn5h0ji",
  dataset: "production",
  apiVersion: "2023-03-09",
};
export default config;
