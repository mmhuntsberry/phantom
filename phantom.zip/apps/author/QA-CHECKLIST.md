# Author Platform IA Expansion QA

- Start Here loads and shows 3 entry cards + subscribe CTA.
- Books index lists all books from Sanity and cards link to detail pages.
- Book detail renders cover, status CTA, content notes collapse, sample, and subscribe block.
- About page renders Sanity copy and photo.
- Newsletter page renders value props and subscribe form.
- Beta readers form submits and creates `betaApplicant` docs.
- Beta thanks page shows unlisted link and survey CTA (noindex).
- Beta packet page renders chapters and CTA (noindex).
- Beta survey submits feedback and creates `betaFeedback` docs.
- Dark mode styling is readable and consistent across new routes.
