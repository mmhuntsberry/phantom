export default function Page() {
  return <div>Hello from Plex</div>;
}
